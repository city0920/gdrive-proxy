# Google Drive API 中转服务

通过 Vercel Edge Function 中转访问 Google Drive API。

## 部署步骤

### 1. 准备代码
确保以下文件结构：
```
vercel-gdrive/
├── api/
│   └── gdrive.js      # API 中转代码
└── vercel.json        # Vercel 配置
```

### 2. 部署到 Vercel

#### 方式 A：通过 Vercel CLI
```bash
# 安装 Vercel CLI
npm i -g vercel

# 进入项目目录
cd vercel-gdrive

# 登录并部署
vercel login
vercel --prod
```

#### 方式 B：通过 GitHub（推荐）
1. 在 GitHub 创建新仓库（如 `gdrive-proxy`）
2. 上传这两个文件
3. 访问 [vercel.com](https://vercel.com)
4. 点击 "Add New Project"
5. 导入你的 GitHub 仓库
6. 点击 "Deploy"

### 3. 获取部署地址

部署成功后，你会得到一个地址：
```
https://your-project-name.vercel.app
```

### 4. 测试访问

```bash
# 测试 API 是否正常工作
curl https://your-project-name.vercel.app/drive/v3/files?pageSize=1

# 应该返回 Google Drive API 的响应
```

### 5. 配置 Python 脚本

修改 `gdrive.py` 中的 Worker 地址：
```python
worker_url = "https://your-project-name.vercel.app"
```

## 使用限制

- **免费额度**：Vercel Hobby 套餐每月 100GB 带宽，足够个人使用
- **超时限制**：Edge Function 最大执行时间 30 秒
- **并发限制**：每秒 1000 个请求（个人使用完全够用）

## 常见问题

### Q: 部署后访问返回 404？
A: 检查 `vercel.json` 中的路由配置是否正确。

### Q: 国内访问 Vercel 也被墙了？
A: 可以为 Vercel 绑定自定义域名（国内可备案域名）。

### Q: 如何绑定自定义域名？
1. 在 Vercel 项目设置中找到 "Domains"
2. 添加你的域名
3. 按提示配置 DNS 解析

## 注意事项

1. 不要将服务账号私钥提交到 GitHub（已使用 JSON 文件本地存储）
2. 定期更新依赖（Vercel 会自动处理）
3. 监控使用量（Vercel 控制台可查看）

## 参考文档

- [Vercel Edge Functions](https://vercel.com/docs/concepts/functions/edge-functions)
- [Google Drive API](https://developers.google.com/drive/api/v3/reference)
